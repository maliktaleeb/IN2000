package no.uio.ifi.in2000.malikts.oblig2.data.alpacas

import android.util.Log
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.gson.gson
import no.uio.ifi.in2000.malikts.oblig2.data.Resource
import no.uio.ifi.in2000.malikts.oblig2.model.alpacas.PartyInfo

data class PartyList(
    val parties: List<PartyInfo>
)

class AlpacaPartiesDataSource{

    private val tag = "AlpacaPartiesDataSource"

    private val path:String = "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/alpacaparties.json"
    private val client =
        HttpClient{
            install(ContentNegotiation){
                gson() // gson > json
            }
        }

    suspend fun fetchPartyData(): Resource {

        return try {
            val response = client.get(path)
            if (response.status == HttpStatusCode.OK){
                val partyList: PartyList = response.body()
                Log.d(tag, "henter respons. ${response.status}")
                Resource.Success(partyList.parties)
            } else{
                Log.d(tag, "something galt: ${response.status}")
                Resource.Error(Exception("feil"))
            }
        } catch (e: Exception){
            Log.d("AlpacaPartiesDataSource", "ikk respons fra api.")
            Resource.Error(e)
        }
    }
}
