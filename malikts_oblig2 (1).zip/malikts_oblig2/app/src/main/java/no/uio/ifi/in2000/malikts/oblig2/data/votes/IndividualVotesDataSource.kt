package no.uio.ifi.in2000.malikts.oblig2.data.votes

import io.ktor.client.call.body
import io.ktor.client.statement.HttpResponse
import no.uio.ifi.in2000.malikts.oblig2.model.votes.District
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes

data class Vote(
    val id:String
)
class IndividualVotesDataSource {

    suspend fun getDistrictVotes(district: District) : List<DistrictVotes>{

        val responseFromAPI: HttpResponse = fetchResponseFromGivenDistrict(district)
        val votesSummary: Map<String, Int> = countVotesForDistrict(responseFromAPI)

        return votesSummary.map {
            DistrictVotes(
                district = district,
                numberOfVotes = it.value,
                partyID = it.key
            )
        }
    }


    private suspend fun countVotesForDistrict(responseData: HttpResponse): Map<String, Int> {
        val allVotes:List<Vote> = responseData.body()
        return allVotes.groupingBy { it.id }
            .eachCount()
            .toList()
            .sortedByDescending { (_ , antallStemmer) -> antallStemmer }
            .toMap()
    }
}
