package no.uio.ifi.in2000.malikts.oblig2.data

import no.uio.ifi.in2000.malikts.oblig2.model.alpacas.PartyInfo
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes

sealed class Resource(
    val parties:List<PartyInfo> = emptyList(),
    val votes:List<DistrictVotes> = emptyList()
) {
    class Success(val data: List<PartyInfo>) : Resource(parties = data)
    data object Loading : Resource()
    data class Error(val exception: Throwable) : Resource()
}