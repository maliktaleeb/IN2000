package no.uio.ifi.in2000.malikts.oblig2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import no.uio.ifi.in2000.malikts.oblig2.ui.home.HomeScreen
import no.uio.ifi.in2000.malikts.oblig2.ui.home.HomeViewModel
import no.uio.ifi.in2000.malikts.oblig2.ui.party.PartyScreen
import no.uio.ifi.in2000.malikts.oblig2.ui.party.PartyViewModel
import no.uio.ifi.in2000.malikts.oblig2.ui.theme.Malikts_oblig2Theme


sealed class Screens(val route:String){
    data object HomeScreen: Screens("ui.home.HomeScreen")
    data object PartyScreen: Screens("ui.party.PartyScreen")
}


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Malikts_oblig2Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {

                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = Screens.HomeScreen.route
                    ){
                        val homeViewModel = HomeViewModel()
                        composable(Screens.HomeScreen.route){
                            HomeScreen(navController = navController, homeViewModel = homeViewModel)
                        }
                        composable("${Screens.PartyScreen.route}/{partyId}"){ backStackEntry ->

                            val id = backStackEntry.arguments?.getString("partyId")!!

                            PartyScreen(
                                navController = navController,
                                partyViewModel = PartyViewModel(partyId = id),
                            )
                        }
                    }
                }
            }


        }
    }
}
