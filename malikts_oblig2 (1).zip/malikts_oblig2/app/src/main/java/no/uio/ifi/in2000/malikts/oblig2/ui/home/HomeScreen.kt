package no.uio.ifi.in2000.malikts.oblig2.ui.home

import android.util.Log
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.sharp.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import no.uio.ifi.in2000.malikts.oblig2.Screens
import no.uio.ifi.in2000.malikts.oblig2.data.Resource

import no.uio.ifi.in2000.malikts.oblig2.model.alpacas.PartyInfo
import no.uio.ifi.in2000.malikts.oblig2.model.votes.District


const val SIDES_PADDING = 20
const val GAP = 30
const val tag = "HomeScreen"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, homeViewModel: HomeViewModel = viewModel()) {

    val partyUIState by homeViewModel.partyUiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Alpaca Parties",
                        fontSize = 24.sp,
                        color = Color.Black
                    )
                },
            )
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (partyUIState.partiesData) {
                is Resource.Loading -> {
                    Log.d(tag, " LoadingContentScreen()..-")
                    LoadingContentScreen()
                }
                is Resource.Success -> {
                    Log.d(tag, " MainContentScreen()...")
                    MainContentScreen(homeViewModel, navController, partyUIState)
                }
                is Resource.Error -> {
                    Log.d(tag, " feil snackbar...")
                }
            }
        }
    }
}

@Composable
fun LoadingContentScreen() {
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
    ) {
        CircularProgressIndicator()
        Text(
            text = "Laster inn...",
            fontSize = 18.sp,
            color = Color.Black
        )
    }
}

@Composable
fun MainContentScreen(homeViewModel: HomeViewModel, navController: NavController, partyUIState: PartyUIState) {
    Column(
        modifier = Modifier
            .padding(
                top = SIDES_PADDING.dp,
                start = SIDES_PADDING.dp,
                end = SIDES_PADDING.dp
            )
    ) {
        Card(
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            modifier = Modifier.padding(bottom = GAP.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                DistrictDropDownMenu(homeViewModel)
                Spacer(modifier = Modifier.height(GAP.dp))
                VoteList(partyUIState.votes, homeViewModel)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items(partyUIState.partiesData.parties) { partyInfo ->
                PartyCard(party = partyInfo, navController = navController)
            }
        }
    }
}

@Composable
fun PartyCard(party: PartyInfo, navController: NavController) {
    val cardHeight = 100
    val cardCornerRoundness = 25
    val paddingFromCard = 10
    val partyColor = Color(android.graphics.Color.parseColor(party.color))

    Card(
        shape = RoundedCornerShape(cardCornerRoundness.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(cardHeight.dp)
            .padding(bottom = 10.dp)
            .clickable {
                navController.navigate("${Screens.PartyScreen.route}/${party.id}")
            }
    ) {
        Row(
            modifier = Modifier
                .padding(
                    start = paddingFromCard.dp,
                    top = paddingFromCard.dp,
                    bottom = paddingFromCard.dp,
                    end = (paddingFromCard + 5).dp
                )
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            AsyncImage(
                model = party.img,
                contentDescription = "Image of ${party.name}s leader, ${party.leader}",
                modifier = Modifier
                    .height((cardHeight * 0.80).dp)
                    .width((cardHeight * 0.80).dp)
                    .clip(RoundedCornerShape((cardCornerRoundness - paddingFromCard).dp)),
                contentScale = ContentScale.Crop
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(start = 10.dp)
            ) {
                Text(
                    modifier = Modifier.fillMaxWidth(),
                    text = party.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black
                )
                Text(
                    text = party.leader,
                    fontStyle = FontStyle.Italic,
                    color = Color.Black
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Icon(
                Icons.AutoMirrored.Sharp.KeyboardArrowRight,
                contentDescription = "See More Info About Party",
                tint = partyColor,
                modifier = Modifier
                    .align(Alignment.CenterVertically)
                    .size(24.dp)
                    .border(
                        shape = CircleShape,
                        width = 4.dp,
                        color = partyColor
                    )
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DistrictDropDownMenu(homeViewModel: HomeViewModel) {
    var expanded by remember { mutableStateOf(false) }
    val itemsAsDistrict = District.entries
    val itemsAsString = listOf("Distrikt 1", "Distrikt 2", "Distrikt 3")
    var selectedIndex by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .height(IntrinsicSize.Max)
            .fillMaxWidth()
    ) {
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded },
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                readOnly = true,
                value = itemsAsString[selectedIndex],
                onValueChange = {},
                label = { Text("Chosen district", color = Color.Black) },
                trailingIcon = {
                    Icon(
                        imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Dropdown Arrow",
                        Modifier.clickable { expanded = !expanded }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .menuAnchor()
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.exposedDropdownSize(),
            ) {
                itemsAsDistrict.forEachIndexed { index, _ ->
                    DropdownMenuItem(
                        text = { Text(text = itemsAsString[index]) },
                        onClick = {
                            selectedIndex = index
                            homeViewModel.loadDistrictVotesData(District.entries[selectedIndex])
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}