package no.uio.ifi.in2000.malikts.oblig2.data.votes

import no.uio.ifi.in2000.malikts.oblig2.model.votes.District
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes

class VotesRepository(
    private val individualVotesDataSource : IndividualVotesDataSource = IndividualVotesDataSource(),
    private val aggregatedVotesDataSource: AggregatedVotesDataSource = AggregatedVotesDataSource(),
)   {

    suspend fun getInfoFromDistrict(district: District): List<DistrictVotes> {

        return if (district == District.district3){
            aggregatedVotesDataSource.getDistrictVotesFromAgregatedSource(district)
        } else{
            individualVotesDataSource.getDistrictVotes(district)
        }
    }

}