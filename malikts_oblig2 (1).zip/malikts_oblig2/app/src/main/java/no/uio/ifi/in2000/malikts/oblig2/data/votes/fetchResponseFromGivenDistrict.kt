package no.uio.ifi.in2000.malikts.oblig2.data.votes

import io.ktor.client.HttpClient
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.client.statement.HttpResponse
import io.ktor.serialization.gson.gson
import no.uio.ifi.in2000.malikts.oblig2.model.votes.District

suspend fun fetchResponseFromGivenDistrict(district: District): HttpResponse {

    val client =
        HttpClient {
            install(ContentNegotiation) {
                gson()
            }
        }

    val baseUrl =
        "https://www.uio.no/studier/emner/matnat/ifi/IN2000/v24/obligatoriske-oppgaver/${district.name}.json"
    return client.get(baseUrl)

}