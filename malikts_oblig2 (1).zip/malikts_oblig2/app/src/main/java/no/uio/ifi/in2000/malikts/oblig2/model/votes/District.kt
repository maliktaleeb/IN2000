package no.uio.ifi.in2000.malikts.oblig2.model.votes

enum class District {
    district1,
    district2,
    district3,

}