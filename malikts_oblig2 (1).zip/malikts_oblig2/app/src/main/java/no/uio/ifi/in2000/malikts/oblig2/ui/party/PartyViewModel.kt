package no.uio.ifi.in2000.malikts.oblig2.ui.party

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import no.uio.ifi.in2000.malikts.oblig2.data.alpacas.AlpacaPartiesRepository
import no.uio.ifi.in2000.malikts.oblig2.model.alpacas.PartyInfo

data class PartyUIState(
    val party: PartyInfo = PartyInfo("", "...","","","#ffffff","")
)
class PartyViewModel(partyId:String) : ViewModel(){



    private val partyRepository: AlpacaPartiesRepository = AlpacaPartiesRepository()
    private val _partyUiState = MutableStateFlow(PartyUIState())
    val partyUiState: StateFlow<PartyUIState> = _partyUiState.asStateFlow()

    init {
        loadOnePartyData(partyId)
    }

    private fun loadOnePartyData(partyId:String) {
        viewModelScope.launch ( Dispatchers.IO ){

            partyRepository.loadFromWeb()

            _partyUiState.update { currentPartyUiState ->
                val partyData = partyRepository.getSinglePartyInfo(partyId)
                currentPartyUiState.copy(party = partyData)
            }
        }
    }
}