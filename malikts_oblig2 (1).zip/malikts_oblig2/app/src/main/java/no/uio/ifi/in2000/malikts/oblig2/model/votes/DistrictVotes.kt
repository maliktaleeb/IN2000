package no.uio.ifi.in2000.malikts.oblig2.model.votes

data class DistrictVotes(

    val district: District,
    val numberOfVotes: Int,
    val partyID: String

)