package no.uio.ifi.in2000.malikts.oblig2.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes


@Composable
fun VoteList(votes: List<DistrictVotes>, homeViewModel: HomeViewModel) {
    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ){
        // Title Row
        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ){
            Text(
                text = "Parti",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.Green
            )
            Text(
                text = "Antall Stemmer",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.Green
            )
        }
        // Body Row
        votes.forEach { districtVotes ->
            ListObject(
                name = homeViewModel.getPartyNameFromId(districtVotes.partyID),
                votes = districtVotes.numberOfVotes.toString()
            )
        }
    }
}

@Composable
fun ListObject(name: String, votes: String) {
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        Text(
            text = name,
            fontSize = 18.sp,
            color = Color.Blue
        )
        Text(
            text = votes,
            fontSize = 18.sp,
            color = Color.Blue
        )
    }
}


