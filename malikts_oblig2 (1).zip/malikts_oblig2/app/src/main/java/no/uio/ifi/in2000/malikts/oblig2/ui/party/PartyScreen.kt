package no.uio.ifi.in2000.malikts.oblig2.ui.party

import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import androidx.compose.ui.Alignment



@Composable
fun PartyScreen(
    partyViewModel: PartyViewModel = viewModel(),
    navController: NavController
){
    val partyUIState by partyViewModel.partyUiState.collectAsState()
    val party = partyUIState.party

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(android.graphics.Color.parseColor(party.color)))
                    .padding(top = 20.dp, bottom = 16.dp)
            ) {
                IconButton(
                    onClick = {
                        if (navController.previousBackStackEntry != null){
                            navController.popBackStack()
                        }
                    },
                    modifier = Modifier.align(Alignment.Start)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
                Text(
                    text = party.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 32.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column (
                modifier = Modifier.padding(16.dp),
            ){
                AsyncImage(
                    model = party.img,
                    contentDescription = "Bilde av ${party.leader}, leder av ${party.name}.",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(20.dp))
                    ,
                    contentScale = ContentScale.Crop,
                )
                Text(
                    text = party.leader,
                    textAlign = TextAlign.Center,
                    fontSize = 24.sp, // Adjusted font size
                    color = Color.Gray, // Changed font color
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )

                Spacer(Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                ){
                    item {
                        Text(
                            text = party.description,
                            fontSize = 20.sp,
                            color = Color.Black,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }
    }
}



