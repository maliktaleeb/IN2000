package no.uio.ifi.in2000.malikts.oblig2.ui.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import no.uio.ifi.in2000.malikts.oblig2.data.Resource
import no.uio.ifi.in2000.malikts.oblig2.data.alpacas.AlpacaPartiesRepository
import no.uio.ifi.in2000.malikts.oblig2.data.votes.VotesRepository
import no.uio.ifi.in2000.malikts.oblig2.model.votes.District
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes

data class PartyUIState(
    val partiesData: Resource = Resource.Loading,
    val votes: List<DistrictVotes> = listOf(),

    val isLoading:Boolean = false,
    val hasError: Throwable? = null
)

class HomeViewModel : ViewModel() {

    private val tag = "HomeViewModel"

    private val partyRepository: AlpacaPartiesRepository = AlpacaPartiesRepository()
    private val votesRepository: VotesRepository = VotesRepository()

    private val _partyUiState = MutableStateFlow(PartyUIState())
    val partyUiState: StateFlow<PartyUIState> = _partyUiState.asStateFlow()


    init {
        viewModelScope.launch {
            partyRepository.allPartiesInfo.collect {
                handleResource(it)
            }
        }

        loadPartyData()
    }


    private fun loadPartyData(){


        Log.d(tag, "Refresher ")

        _partyUiState.update {
            it.copy(
                partiesData = Resource.Loading
            )
        }

        viewModelScope.launch ( Dispatchers.IO ){
            partyRepository.loadFromWeb()
        }
        Log.d(tag, "ferdig.")
    }

    fun loadDistrictVotesData(district: District) {

        viewModelScope.launch( Dispatchers.IO ) {
            _partyUiState.update {
                it.copy(votes = votesRepository.getInfoFromDistrict(district))
            }
        }
    }

    fun getPartyNameFromId(id:String):String{
        return partyRepository.getPartyNameFromId(id)
    }

    private fun handleResource(resource: Resource){

        when (resource) {
            is Resource.Success -> {
                Log.d(tag, "Doppdatert til suksesse...")


                loadDistrictVotesData(District.district1)

                _partyUiState.update {
                    it.copy(
                        partiesData = resource,
                        isLoading = false,
                        hasError = null
                    )
                }
            }

            is Resource.Error -> {
                Log.d(tag, "error: ${resource.exception}")
                _partyUiState.update {
                    it.copy(
                        partiesData = resource,
                        hasError = resource.exception,
                        isLoading = false
                    )
                }
            }

            is Resource.Loading -> {
                Log.d(tag, "no data...")
                _partyUiState.update {
                    it.copy(isLoading = true)
                }
            }
        }
    }
}