package no.uio.ifi.in2000.malikts.oblig2.data.votes

import io.ktor.client.call.body
import no.uio.ifi.in2000.malikts.oblig2.model.votes.District
import no.uio.ifi.in2000.malikts.oblig2.model.votes.DistrictVotes

class AggregatedVotesDataSource {

    data class PartialDistrictVotes(
        val votes: Int,
        val partyId: String
    )

    data class ListPartialDisrictVotes(
        val parties: List<PartialDistrictVotes>
    )

    suspend fun getDistrictVotesFromAgregatedSource(district: District) : List<DistrictVotes>{

        val response = fetchResponseFromGivenDistrict(district)
        val allPartialDistrictVotes : ListPartialDisrictVotes = response.body()

        return allPartialDistrictVotes.parties.map { partialInfo ->
            DistrictVotes(
                partyID = partialInfo.partyId,
                district = district,
                numberOfVotes = partialInfo.votes
            )
        }
    }
}
