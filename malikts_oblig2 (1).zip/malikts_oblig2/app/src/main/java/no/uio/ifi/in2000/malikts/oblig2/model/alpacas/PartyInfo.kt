package no.uio.ifi.in2000.malikts.oblig2.model.alpacas

data class PartyInfo(
    val id: String,
    val name: String,
    val leader: String,
    val img: String,
    val color: String,
    val description: String

)