package no.uio.ifi.in2000.malikts.oblig2.data.alpacas


import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import no.uio.ifi.in2000.malikts.oblig2.data.Resource
import no.uio.ifi.in2000.malikts.oblig2.model.alpacas.PartyInfo

class AlpacaPartiesRepository(
    private val alpacaPartiesDataSource: AlpacaPartiesDataSource = AlpacaPartiesDataSource()
) {

    private val tag = "AlpacaPartiesRepository"

    val allPartiesInfo = MutableStateFlow<Resource>(Resource.Loading)

    suspend fun loadFromWeb() {
        Log.d(tag, "...")
        allPartiesInfo.update { alpacaPartiesDataSource.fetchPartyData() }
        Log.d(tag, " (${allPartiesInfo.value} partier)")
    }

    fun getSinglePartyInfo(id:String): PartyInfo {
        return allPartiesInfo.value.parties.first{ it.id == id}

    }

    fun getPartyNameFromId(id: String): String {
        return getSinglePartyInfo(id).name
    }
}